#include <iostream>
#include <vector>
#include <cstdlib>

void RepiteUltimoDigito (int usuario) {

  std::cin >> usuario;
  int* array= new int[usuario];
  std::vector <int> ContarCifras;

  for (int i = 0; i < usuario-1; i++) {

    ContarCifras [i] = 0;
    std::cout << ContarCifras << std::endl;

  }


}